<script lang="ts">
    // Typescript
</script>

<head>
    <title> Andrea Dao - Milestone 1 </title>
</head>
<body>
    <h1> Read some sample blogs! (Andrea being upset at things) </h1>
    <a href ="/blog1"> Blog 1 </a>
    <a href ="/blog2"> Blog 2 </a>
    <a href ="/blog3"> Blog 3 </a>

</body>

<style>
    body {
        background-color: black;
        margin: 0;
        padding: 0;
        color: white;
    }
    h1 {
        font-family: kanit;
        font-size: 400%;
        text-align: center;
    }
    a {
        text-align: center;
        display:block;
        font-family: kanit;
        font-size: 400%;
        padding-bottom: 5dvi;
    }
</style>