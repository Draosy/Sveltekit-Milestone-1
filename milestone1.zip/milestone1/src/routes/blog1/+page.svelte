<script lang="ts">
    // typescript
</script>

<head>
    <title>
        Blog 1 
    </title>
</head>
<body>
    <a href = "/"> Home </a>
    <h1 style = "font-family:serif; font-size: 500%;"> Blog 1 </h1>
    <h2 style = "font-family:serif; font-size: 200%;"> June 9, 2021 </h2>
    <img src = "reynapose.png" width = 20% height = 20% alt = "">
    <p> I really hate this stupid game called Valorant but I'm still addicted to it. 
            It's really a toxic relationship that's almost as toxic as instalocking Reyna 
            or any other duelist especially Yoru. Welcome to my yap-fest about Valorant. 
            *crying sobbing throwing up*</p>
</body>

<style>
    h1 {
        text-align: center;
        display:block;
    }
    h2 {
        text-align: center;
        display:block;
    }
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 20%;
    }
    p {
        text-align: center;
        display:block;
        padding-top: 2%;
        font-size: 200%;
    }
    a {
        text-align: center;
        display:block;
        font-size: 300%;
    }
</style>