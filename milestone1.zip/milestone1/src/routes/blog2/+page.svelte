<script lang="ts">
    // typescript
</script>

<head>
    <title>
        Blog 2
    </title>
</head>
<body>
    <a href = "/"> Home </a>
    <h1 style = "font-family:serif; font-size: 500%;"> Blog 2 </h1>
    <h2 style = "font-family:serif; font-size: 200%;"> April 20, 2022 </h2>
    <img src = "noew.png" width = 20% height = 20% alt = "">
    <p> Whoever made this deserves jail time like- How did they manage to make it taste like a bar of soap?
        Ooh the apple crisp part sounds appealing but whatever oatmilk even is just completely negates
        the apple crisp. I'm no food connoisseur but I know what soap tastes like accidentally. This is pretty
        close to it. Also, why is Starbucks so expensive 😭. 
    </p>
</body>

<style>
    h1 {
        text-align: center;
        display:block;
    }
    h2 {
        text-align: center;
        display:block;
    }
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
    }
    p {
        text-align: center;
        display:block;
        padding-top: 2%;
        font-size: 200%;
    }
    a {
        text-align: center;display:block;
        font-size: 300%;
    }
</style>