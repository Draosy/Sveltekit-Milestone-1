<script lang="ts">
    // typescript
</script>

<head>
    <title>
        Blog 3
    </title>
</head>
<body>
    <a href = "/"> Home </a>
    <h1 style = "font-family:serif; font-size: 500%;"> Blog 3 </h1>
    <h2 style = "font-family:serif; font-size: 200%;"> December 27, 2023 </h2>
    <img src = "actualthonk.png" width = 20% height = 20% alt = "">
    <p> Existential crisis time. Do I even have a personality? I was 
        struggling to come up with blog post ideas because I'm either
    too scared to share things I actually think about or like or because
my days are just occupied with homework and sleep and feeling empty. 
I should actually be coding instead of writing these fake blog posts. 
But let me have a diva moment just for a second geez. Like what if I don't 
think actual original thoughts? This blog post is proof of contradiction... 
right? Or did I just steal this personality from someone... who knows. Oh well. </p>
</body>

<style>
    h1 {
        text-align: center;
        display:block;
    }
    h2 {
        text-align: center;
        display:block;
    }
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 20%;
    }
    p {
        text-align: center;
        display:block;
        padding-top: 2%;
        font-size: 200%;
    }
    a {
        text-align: center;display:block;
        font-size: 300%;
    }
</style>